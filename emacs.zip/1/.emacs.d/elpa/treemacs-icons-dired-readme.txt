Treemacs icons for dired. Code is based on all-the-icons-dired.el
