Display org-agenda items in the calfw buffer.
(Because I don't use the org-agenda mainly,
I hope someone continue integration with the org.)

(require 'calfw-org)

use org agenda buffer style keybinding.
(setq cfw:org-overwrite-default-keybinding t)

M-x cfw:open-org-calendar
