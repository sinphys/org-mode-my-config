A dark theme  for dark minds.  > Emacs 24
