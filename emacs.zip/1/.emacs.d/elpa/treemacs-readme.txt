A powerful and flexible file tree project explorer.
