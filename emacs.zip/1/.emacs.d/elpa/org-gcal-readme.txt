Put the org-gcal.el to your
load-path.
Add to .emacs:
(require 'org-gcal)
